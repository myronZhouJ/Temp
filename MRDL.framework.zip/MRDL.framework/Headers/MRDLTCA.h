//
//  MRDLTCA.h
//  MRDL
//
//  Created by Myron on 2019/5/25.
//  Copyright © 2019 Wishnote. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MRDLTCA : NSObject

@end

NS_ASSUME_NONNULL_END
