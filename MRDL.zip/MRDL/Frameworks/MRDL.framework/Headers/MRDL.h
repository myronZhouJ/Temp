//
//  MRDL.h
//  MRDL
//
//  Created by Myron on 2019/5/25.
//  Copyright © 2019 Wishnote. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MRDL.
FOUNDATION_EXPORT double MRDLVersionNumber;

//! Project version string for MRDL.
FOUNDATION_EXPORT const unsigned char MRDLVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MRDL/PublicHeader.h>

#import <MRDL/MRDLTCA.h>
